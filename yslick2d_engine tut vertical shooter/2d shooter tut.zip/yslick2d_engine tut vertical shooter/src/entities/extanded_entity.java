package entities;

import org.newdawn.slick.SlickException;

import yengine.yentity;

public class extanded_entity extends yentity {

	public extanded_entity() {
		// TODO Auto-generated constructor stub
	}

	public extanded_entity(float x, float y, float speed, String img) throws SlickException {
		super(x, y, speed, img);
		// TODO Auto-generated constructor stub
	}

}
