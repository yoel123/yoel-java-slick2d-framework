package entities;

import java.util.ArrayList;
import java.util.Random;

import org.newdawn.slick.SlickException;

import yengine.yengine;
import yengine.yentity;

public class sun extends yentity 
{
	public sun(float x, float y,String img) throws SlickException 
	{
		super( x, y, 0, img);
		type = "sun";
	}
	public void update() throws SlickException
	{
		click();
	}//end update
	public void click() throws SlickException
	{
		if(clicked(0))
		{
			yengine.o("click sun");
			reset_stars();
			rand_pos();
		}
	}//end click
	public void reset_stars()
	{
		ArrayList<yentity> mcs = get_by_type("star");
		for(yentity e : mcs)
		{
			e.alpha=1;
		}
	}//end reset stars
	public void rand_pos()
	{
		Random r = new Random();
		
		 x = 30+r.nextInt(300);
		 y = 30+r.nextInt(270);
	}//end rand_pos
}//end star
