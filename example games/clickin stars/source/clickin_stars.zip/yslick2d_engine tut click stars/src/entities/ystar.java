package entities;

import java.util.Random;

import org.newdawn.slick.SlickException;

import screens.game_world;
import yengine.yengine;
import yengine.yentity;

public class ystar extends yentity
{
	public ystar(float x, float y,String img) throws SlickException 
	{
		super( x, y, 0, img);
		type = "star";
	}
	public void init() throws SlickException
	{
		super.init();
		rand_pos();
	}
	public void update() throws SlickException
	{
		click();
		fade();
	}//end update
	
	public void click() throws SlickException
	{
		if(clicked(0) && alpha >0)
		{
			yengine.o("click star");
			rand_pos();
			game_world yworld = (game_world)world;
			yworld.score++;
			
		}
	}//end click
	public void rand_pos()
	{
		 Random r = new Random();
		
		 x = 20+r.nextInt(300);
		 y = 20+r.nextInt(300);
	}//end rand_pos
	public void fade()
	{
		if(alpha>0)
		{
			alpha -=0.0001;
		}
		if(alpha<0.005)
		{
			alpha=0;
		}
	}//end fade
	
}//end ystar
