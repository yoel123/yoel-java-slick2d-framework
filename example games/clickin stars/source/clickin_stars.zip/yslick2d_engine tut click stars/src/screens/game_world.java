package screens;

import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.StateBasedGame;

import entities.ystar;
import entities.sun;
import yengine.yengine;
import yengine.yworld;

public class game_world extends yworld
{
	public int score = 0;
	public String rank="none"; 
	public game_world(int state) throws SlickException 
	{
		super(state);
	
		
		
	}
	
	@Override
	public void yinit(GameContainer gc, StateBasedGame sbg) throws SlickException 
	{
		ystar ys;
		sun ysun = new sun(150.0f,50.0f,"sun.png");
		
	    
	   add(ysun);
	 
	    for(int i =0 ; i<=3;i++)
	    {
	    	ys = new ystar(150.0f,150.0f,"Star.png");
			
		    add(ys);
		    
	    }
	
			
	}
	
	@Override
	public void render(GameContainer gc, StateBasedGame sbg, Graphics g) throws SlickException 
	{
		super.render( gc,sbg, g);
		yengine.ds(g, "score: "+score, 20, 20);
		yengine.ds(g, "rank: "+rank, 220, 20);
		if(score>4){this.rank="star clicker";}
		if(score>15){this.rank="pro star clicker";}
		if(score>25){this.rank="master star clicker";}
		if(score>30){this.rank="no life";}
		if(score>35){this.rank="you shod stop you know";}
		if(score>40){this.rank="this game never ends";}
		if(score>45){this.rank="just sying its youre life...";}
		if(score>50){this.rank="good job you win";}
		if(score>60){this.rank="you can stop now";}
		
		
		
		
	}

}//end game_world
